import json
import tempfile
import unittest
from datetime import datetime, date
from pathlib import Path
from zoneinfo import ZoneInfo
from unittest.mock import Mock

from autopilot import BufferAPI, caption_for, episodes_from_clips, next_time, parse_existing, make_video


class AutoPilotTests(unittest.TestCase):
    def test_episode_sequence(self):
        clips = {(14,"A"): "a", (14,"B"): "b", (15,"A"): "a", (16,"A"): "a", (16,"B"): "b"}
        self.assertEqual(episodes_from_clips(clips, 14), [14])

    def test_duplicate_detection_per_network(self):
        posts = [
            {"channelId": "instagram-id", "text": "Épisode 14 #FruitsEP014", "status": "scheduled"},
            {"channelId": "tiktok-id", "text": "Épisode 14 #FruitsEP014", "status": "sent"},
            {"channelId": "instagram-id", "text": "other", "status": "scheduled"},
        ]
        existing, queued = parse_existing(posts)
        self.assertIn(("instagram-id", 14), existing)
        self.assertIn(("tiktok-id", 14), existing)
        self.assertNotIn(("youtube-id", 14), existing)
        self.assertEqual(queued["instagram-id"], 2)

    def test_caption_ai_and_marker(self):
        title, body = caption_for(27, {})
        self.assertIn("#FruitsEP027", body)
        self.assertIn("Épisode 27", title)

    def test_first_date_and_late_publication(self):
        cfg = {"start_date": date(2026,12,8),"start_episode":14,"post_hour":15,"post_minute":0,"timezone":ZoneInfo("Europe/Paris")}
        self.assertEqual(next_time(14,cfg,datetime(2026,12,7,10,tzinfo=cfg["timezone"]),set()).date().isoformat(),"2026-12-08")
        self.assertEqual(next_time(14,cfg,datetime(2026,12,10,16,tzinfo=cfg["timezone"]),set()).date().isoformat(),"2026-12-11")
        self.assertEqual(next_time(14,cfg,datetime(2026,12,7,10,tzinfo=cfg["timezone"]),{date(2026,12,8)}).date().isoformat(),"2026-12-09")

    def test_buffer_create_payload(self):
        fake = Mock()
        fake.post.return_value.status_code = 200
        fake.post.return_value.json.return_value = {"data":{"createPost":{"post":{"id":"p1"}}}}
        instance = BufferAPI("dummy",http=fake)
        post_id=instance.create(channel_id="abc",service="instagram",when=datetime(2026,12,8,15,tzinfo=ZoneInfo("Europe/Paris")),url="https://res.cloudinary.com/demo/video/upload/fruit.mp4",title="Fruits",caption="#FruitsEP014",for_kids=False)
        self.assertEqual(post_id,"p1")
        payload=fake.post.call_args.kwargs["json"]["variables"]["input"]
        self.assertEqual(payload["dueAt"],"2026-12-08T14:00:00.000Z")
        self.assertTrue(payload["metadata"]["instagram"]["isAiGenerated"])

    def test_ffmpeg_real_two_clips(self):
        # Two tiny generated clips; no access to user's private source media in tests.
        import subprocess
        with tempfile.TemporaryDirectory() as folder:
            a,b,output=(Path(folder)/name for name in ("a.mp4","b.mp4","final.mp4"))
            subprocess.run(["ffmpeg","-v","error","-y","-f","lavfi","-i","color=c=red:s=144x256:r=30:d=0.4","-c:v","libx264","-pix_fmt","yuv420p",str(a)],check=True)
            subprocess.run(["ffmpeg","-v","error","-y","-f","lavfi","-i","color=c=blue:s=144x256:r=30:d=0.4","-c:v","libx264","-pix_fmt","yuv420p",str(b)],check=True)
            make_video(a,b,output)
            self.assertTrue(output.exists())
            self.assertGreater(output.stat().st_size,1000)
            probe=subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height","-of","json",str(output)],capture_output=True,text=True,check=True)
            stream=json.loads(probe.stdout)["streams"][0]
            self.assertEqual((stream["width"],stream["height"]),(1080,1920))

if __name__ == "__main__":
    unittest.main()
